<?php get_header(); ?>

    <div  class="no_page">        <h3><?php _e( 'おっとっと！ ページが見つかりません。'); ?></h3>        <h6><?php _e( 'お探しのページが見つかりませんでした。たぶんあなたは検索してみることができます:'); ?></h6>    </div>

<?php get_footer(); ?>