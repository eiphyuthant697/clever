<div class="container contact-section">
    <div class="row main-container contact">
    	<?php the_content();?>
    </div>    
</div>