<?php get_header(); ?>

<?php get_template_part('index'); ?>

<?php get_footer(); ?>